<html>
    <head>
        
    </head>
    <body>        
        
        <form action="procesador.php">
        <input type="text" name="latitud">
        <input type="text" name="longitud">
        <input type="submit" >
            
        </form>
</body>

</html>


